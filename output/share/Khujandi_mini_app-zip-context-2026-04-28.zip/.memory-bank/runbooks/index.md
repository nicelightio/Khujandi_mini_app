---
description: Роутер по operational runbooks проекта.
status: active
---
# Runbooks Index

- [.memory-bank/runbooks/manual-refund-and-negative-alerts.md](manual-refund-and-negative-alerts.md): Операционный runbook для ручного refund и эскалации негативных отзывов.
- [.memory-bank/runbooks/ft-010-manual-verification.md](ft-010-manual-verification.md): Ручной прогон provisioning, shared storefront seller edit mode, seller-web status toggle и visibility gating для `FT-010`.
- [.memory-bank/runbooks/security-auth-and-secret-response.md](security-auth-and-secret-response.md): Операционный runbook для lockout-response, token compromise и rotation секретов.
- [.memory-bank/runbooks/telegram-mini-app-verification.md](telegram-mini-app-verification.md): Runbook проверки Telegram-specific auth/payment/WebView behavior в test environment и client matrix.
- [.memory-bank/runbooks/telegram-mini-app-test-server-deploy.md](telegram-mini-app-test-server-deploy.md): Runbook развертывания тестового VPS, Cloudflare subdomain и первого Android Telegram запуска Mini App.
- [.memory-bank/runbooks/telegram-mini-app-container-deploy.md](telegram-mini-app-container-deploy.md): Канонический runbook текущего серверного разворота на тот же VPS через containerized deploy, cleanup legacy файлов и выделенный app user.
